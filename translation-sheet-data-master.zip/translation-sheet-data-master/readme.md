# Translation sheet data
This is a row export of the [ACNH Translation sheet](https://tinyurl.com/acnh-translations) to JSON format. Each tab is coverted to JSON without further processing.
